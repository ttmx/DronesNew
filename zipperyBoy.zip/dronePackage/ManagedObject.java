package dronePackage;

public interface ManagedObject {
    public String getObjectID();
}
