package dronePackage;
public class Sociable extends DroneClass{
    
}